#pragma once
#pragma once
#include "CDrawManager.h"

DWORD black = COLORCODE(0, 0, 0, 255);
DWORD white = COLORCODE(255, 255, 255, 255);
DWORD light = COLORCODE(200, 200, 200, 255);
DWORD menuBack = COLORCODE(2, 2, 15, 200);
DWORD dark = COLORCODE(30, 30, 30, 255);
DWORD bluTeam = COLORCODE(0, 128, 255, 255);
DWORD redTeam = COLORCODE(186, 52, 53, 255);